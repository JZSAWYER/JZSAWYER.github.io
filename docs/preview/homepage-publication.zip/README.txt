Homepage publication handoff — approved FlagCounter Mini version

Repository: https://github.com/JZSAWYER/JZSAWYER.github.io
Patch base: 51d871249005c7e0061f7a802d64a66958df208a

The owner approved the homepage content, typography, interactions and the
FlagCounter Mini pageviews-only footer. The existing counter ID is retained.
The homepage shows no country table or map; the provider's linked statistics
page can still contain geographic data.

Publication is unfinished. The bot workspace's installed Git guard permits
only its registered branch and rejects pushes to main. This archive supplies
the reviewed source changes for an operator with an approved publishing path.
It does not change any protection or hosting setting.

In a clean main checkout at the base commit above:
  git apply --check /path/to/homepage-publication.patch
  git apply /path/to/homepage-publication.patch
  bundle exec jekyll build --destination /path/to/temporary-build-output

Review the diff, then commit and push through the approved publishing path.
Verify GitHub's Pages deployment and https://jzsawyer.github.io/ afterward.
If main has advanced, review/rebase the changes rather than forcing a push.

Validation: local Jekyll 3.9.3 build passed with the configured plugins and
locked site dependencies. The full github-pages dependency bundle was not
validated in this environment. The standalone HTML content and focused Mini
counter browser checks passed. Patch application against the base index was
checked without changing the working branch. No deployment has occurred.

Only site source, bundled font licenses and used new publication figures are
included. Management records, preview artifacts and private attachments are
excluded. Existing unrelated repository files are preserved.
