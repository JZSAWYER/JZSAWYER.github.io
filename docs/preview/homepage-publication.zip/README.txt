Approved FlagCounter homepage publication

Repository: https://github.com/JZSAWYER/JZSAWYER.github.io
Base main commit: 51d871249005c7e0061f7a802d64a66958df208a

The patch contains the reviewed homepage content, layout, typography, scripts,
fonts with their license, and publication figures. It restores the full
FlagCounter and ClustrMaps footer. It excludes bot management records, preview
files, private attachments and unrelated draft assets.

An operator with an approved publishing path can apply it from a clean main
checkout:

  git apply --check homepage-publication.patch
  git apply homepage-publication.patch
  bundle exec jekyll build

Review and commit the changed website files, then push main through the
repository's normal approved publisher. GitHub Pages deploys from main.
The bot workspace's installed Git guard currently rejects main pushes.
No protection or hook has been disabled, and the live site has not changed.
